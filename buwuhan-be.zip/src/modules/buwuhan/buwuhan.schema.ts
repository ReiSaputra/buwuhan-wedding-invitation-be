import * as z from "zod";

export const ALLOWED_UNITS = ["transaksi", "kg", "gram", "liter", "karung", "ekor", "unit", "pack", "box", "orang", "jasa"] as const;

export const buwuhanItemSchema = z.object({
  itemName: z.string().trim().min(1, "Nama bantuan wajib diisi").max(255, "Nama bantuan maksimal 255 karakter"),
  quantity: z.number().positive("Jumlah harus lebih dari 0"),
  unit: z.enum(ALLOWED_UNITS, { message: "Satuan tidak valid" }),
  category: z.string().trim().max(100, "Kategori maksimal 100 karakter").optional().nullable(),
  estimatedValue: z.number().nonnegative("Estimasi nilai tidak boleh negatif").optional().nullable(),
});

export const createBuwuhanSchema = z.object({
  giverName: z.string().trim().min(1, "Nama pemberi wajib diisi").max(255, "Nama pemberi maksimal 255 karakter"),
  giverAddress: z.string().trim().max(500, "Alamat maksimal 500 karakter").optional().nullable(),
  note: z.string().trim().max(1000, "Catatan maksimal 1000 karakter").optional().nullable(),
  receivedAt: z.string().datetime({ message: "Format tanggal tidak valid (gunakan ISO 8601)" }).optional(),
  items: z.array(buwuhanItemSchema).min(1, "Minimal 1 item bantuan"),
});

export const updateBuwuhanSchema = z
  .object({
    giverName: z.string().trim().min(1, "Nama pemberi wajib diisi").max(255).optional(),
    giverAddress: z.string().trim().max(500, "Alamat maksimal 500 karakter").optional().nullable(),
    note: z.string().trim().max(1000).optional().nullable(),
    receivedAt: z.string().datetime({ message: "Format tanggal tidak valid" }).optional(),
    items: z.array(buwuhanItemSchema).min(1, "Minimal 1 item bantuan").optional(),
  })
  .refine((data) => Object.keys(data).length > 0, {
    message: "Minimal satu field harus diisi untuk update",
  });

export const exportBuwuhanQuerySchema = z.object({
  format: z.enum(["csv", "xlsx"], { message: "Format export harus 'csv' atau 'xlsx'" }).default("csv"),
  category: z.string().trim().optional(),
  search: z.string().trim().optional(),
});

export type CreateBuwuhanInput = z.infer<typeof createBuwuhanSchema>;
export type UpdateBuwuhanInput = z.infer<typeof updateBuwuhanSchema>;
export type ExportBuwuhanQueryInput = z.infer<typeof exportBuwuhanQuerySchema>;
