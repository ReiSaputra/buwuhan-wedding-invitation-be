import type { Celebrant, Couple, GalleryPhoto, GiftAccount, Invitation, InvitationStatus, LoveStory, Prisma, Template, EventCategory, PlanTier } from "../../generated/prisma/client";

export type InvitationWithRelations = Invitation & {
  couples: Couple[];
  celebrant?: Celebrant | null;
  template: Template | null;
  galleryPhotos: GalleryPhoto[];
  loveStories: LoveStory[];
  giftAccounts?: GiftAccount[];
};

export type CoupleType = "BRIDE" | "GROOM";
export type InvitationStatusType = "DRAFT" | "ACTIVE" | "COMPLETED";

export interface CoupleInput {
  type: CoupleType;
  name: string;
  fatherName: string;
  motherName: string;
}

export interface CelebrantInput {
  name: string;
  nickname?: string | null | undefined;
  fatherName: string;
  motherName: string;
  gender?: "MALE" | "FEMALE" | null | undefined;
  birthDate?: Date | string | null | undefined;
  childOrder?: number | null | undefined;
}

export interface CreateInvitationReq {
  title: string;
  slug: string;
  eventCategory?: EventCategory | undefined;
  couples?: CoupleInput[] | undefined;
  celebrant?: CelebrantInput | undefined;
  eventDate?: Date | string | undefined;
  eventTime?: string | undefined;
  venue?: string | undefined;
  address?: string | undefined;
  giftAddress?: string | null | undefined;
  additionalInfo?: Prisma.InputJsonValue | undefined;
  templateId?: string | undefined;
}

export interface UpdateInvitationReq {
  title?: string | undefined;
  slug?: string | undefined;
  eventCategory?: EventCategory | undefined;
  couples?: CoupleInput[] | undefined;
  celebrant?: CelebrantInput | null | undefined;
  eventDate?: Date | string | null | undefined;
  eventTime?: string | null | undefined;
  venue?: string | null | undefined;
  address?: string | null | undefined;
  giftAddress?: string | null | undefined;
  additionalInfo?: Prisma.InputJsonValue | undefined;
  templateId?: string | undefined;
}

export interface UpdateInvitationStatusReq {
  status: InvitationStatusType;
}

export interface AddGalleryPhotoReq {
  imageUrl: string;
  caption?: string | null | undefined;
  order?: number | undefined;
}

export interface UpdateGalleryPhotoReq {
  imageUrl?: string | undefined;
  caption?: string | null | undefined;
  order?: number | undefined;
}

export interface AddLoveStoryReq {
  yearOrDate: string;
  title: string;
  story: string;
  imageUrl?: string | null | undefined;
  order?: number | undefined;
}

export interface UpdateLoveStoryReq {
  yearOrDate?: string | undefined;
  title?: string | undefined;
  story?: string | undefined;
  imageUrl?: string | null | undefined;
  order?: number | undefined;
}

export interface GalleryPhotoData {
  id: string;
  imageUrl: string;
  caption: string | null;
  order: number;
  createdAt: Date;
}

export interface LoveStoryData {
  id: string;
  yearOrDate: string;
  title: string;
  story: string;
  imageUrl: string | null;
  order: number;
  createdAt: Date;
}

export interface CelebrantData {
  id: string;
  name: string;
  nickname: string | null;
  fatherName: string;
  motherName: string;
  gender: string | null;
  birthDate: Date | null;
  childOrder: number | null;
}

export interface InvitationData {
  id: string;
  title: string;
  slug: string;
  status: InvitationStatusType;
  eventCategory: EventCategory;
  showCouples: boolean;
  showCelebrant: boolean;
  celebrant: CelebrantData | null;
  publishedAt: Date | null;
  eventDate: Date | null;
  eventTime: string | null;
  venue: string | null;
  address: string | null;
  giftAddress: string | null;
  additionalInfo: unknown;
  couples: {
    type: string;
    name: string;
    fatherName: string;
    motherName: string;
  }[];
  template: {
    id: string;
    name: string;
    slug: string;
  } | null;
  galleryPhotos: GalleryPhotoData[];
  loveStories: LoveStoryData[];
  giftAccounts: {
    id: string;
    bankName: string;
    accountNumber: string;
    accountHolder: string;
    type: string;
    order: number;
  }[];
}

export interface CreateInvitationRes {
  message: string;
  status: number;
  data: InvitationData;
}

export interface GetInvitationRes {
  message: string;
  status: number;
  data: InvitationData;
}

export interface ListInvitationRes {
  message: string;
  status: number;
  data: InvitationData[];
}

export interface UpdateInvitationRes {
  message: string;
  status: number;
  data: InvitationData;
}

export interface UpdateInvitationStatusRes {
  message: string;
  status: number;
  data: InvitationData;
}

export interface DeleteInvitationRes {
  message: string;
  status: number;
}

export interface GalleryPhotoRes {
  message: string;
  status: number;
  data: GalleryPhotoData;
}

export interface LoveStoryRes {
  message: string;
  status: number;
  data: LoveStoryData;
}

export function toInvitationData(invitation: InvitationWithRelations): InvitationData {
  return {
    id: invitation.id,
    title: invitation.title,
    slug: invitation.slug,
    status: invitation.status as InvitationStatusType,
    eventCategory: invitation.eventCategory,
    showCouples: invitation.eventCategory === "WEDDING",
    showCelebrant: invitation.eventCategory !== "WEDDING",
    celebrant: invitation.celebrant
      ? {
          id: invitation.celebrant.id,
          name: invitation.celebrant.name,
          nickname: invitation.celebrant.nickname,
          fatherName: invitation.celebrant.fatherName,
          motherName: invitation.celebrant.motherName,
          gender: invitation.celebrant.gender,
          birthDate: invitation.celebrant.birthDate,
          childOrder: invitation.celebrant.childOrder,
        }
      : null,
    publishedAt: invitation.publishedAt,
    eventDate: invitation.eventDate,
    eventTime: invitation.eventTime,
    venue: invitation.venue,
    address: invitation.address,
    giftAddress: invitation.giftAddress,
    additionalInfo: invitation.additionalInfo,
    couples: (invitation.couples ?? []).map((c) => ({
      type: c.type,
      name: c.name,
      fatherName: c.fatherName,
      motherName: c.motherName,
    })),
    template: invitation.template
      ? {
          id: invitation.template.id,
          name: invitation.template.name,
          slug: invitation.template.slug,
        }
      : null,
    galleryPhotos: (invitation.galleryPhotos ?? []).map((g) => ({
      id: g.id,
      imageUrl: g.imageUrl,
      caption: g.caption,
      order: g.order,
      createdAt: g.createdAt,
    })),
    loveStories: (invitation.loveStories ?? []).map((s) => ({
      id: s.id,
      yearOrDate: s.yearOrDate,
      title: s.title,
      story: s.story,
      imageUrl: s.imageUrl,
      order: s.order,
      createdAt: s.createdAt,
    })),
    giftAccounts: (invitation.giftAccounts ?? []).map((ga) => ({
      id: ga.id,
      bankName: ga.bankName,
      accountNumber: ga.accountNumber,
      accountHolder: ga.accountHolder,
      type: ga.type,
      order: ga.order,
    })),
  };
}

export function createInvitationResponse(invitation: InvitationWithRelations): CreateInvitationRes {
  return {
    message: "Undangan berhasil dibuat",
    status: 201,
    data: toInvitationData(invitation),
  };
}

export function getInvitationResponse(invitation: InvitationWithRelations): GetInvitationRes {
  return {
    message: "Undangan ditemukan",
    status: 200,
    data: toInvitationData(invitation),
  };
}

export function listInvitationResponse(invitations: InvitationWithRelations[]): ListInvitationRes {
  return {
    message: "Daftar undangan berhasil diambil",
    status: 200,
    data: invitations.map(toInvitationData),
  };
}

export function updateInvitationResponse(invitation: InvitationWithRelations): UpdateInvitationRes {
  return {
    message: "Undangan berhasil diperbarui",
    status: 200,
    data: toInvitationData(invitation),
  };
}

export function updateInvitationStatusResponse(invitation: InvitationWithRelations): UpdateInvitationStatusRes {
  return {
    message: "Status undangan berhasil diperbarui",
    status: 200,
    data: toInvitationData(invitation),
  };
}

export function deleteInvitationResponse(): DeleteInvitationRes {
  return {
    message: "Undangan berhasil dihapus",
    status: 200,
  };
}

export function galleryPhotoResponse(photo: GalleryPhoto, message = "Foto galeri berhasil disimpan", status = 200): GalleryPhotoRes {
  return {
    message,
    status,
    data: {
      id: photo.id,
      imageUrl: photo.imageUrl,
      caption: photo.caption,
      order: photo.order,
      createdAt: photo.createdAt,
    },
  };
}

export function loveStoryResponse(story: LoveStory, message = "Kisah cinta berhasil disimpan", status = 200): LoveStoryRes {
  return {
    message,
    status,
    data: {
      id: story.id,
      yearOrDate: story.yearOrDate,
      title: story.title,
      story: story.story,
      imageUrl: story.imageUrl,
      order: story.order,
      createdAt: story.createdAt,
    },
  };
}

// ── Admin Invitation Management Types ───────────────────────────────

export interface AdminInvitationListItem {
  id: string;
  title: string;
  slug: string;
  status: InvitationStatusType;
  eventCategory: EventCategory;
  eventDate: Date | null;
  eventTime: string | null;
  venue: string | null;
  address: string | null;
  createdAt: Date;
  updatedAt: Date;
  owner: {
    id: string;
    fullName: string;
    email: string;
    planTier: PlanTier;
  };
  template: {
    id: string;
    name: string;
    slug: string;
    previewImageUrl: string;
  } | null;
  stats: {
    totalGuests: number;
    totalRsvps: number;
  };
}

export interface AdminInvitationListPaginationMeta {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface AdminInvitationListRes {
  message: string;
  status: number;
  data: {
    invitations: AdminInvitationListItem[];
    pagination: AdminInvitationListPaginationMeta;
  };
}

export interface AdminInvitationDetailData extends InvitationData {
  owner: {
    id: string;
    fullName: string;
    email: string;
    planTier: PlanTier;
  };
  stats: {
    totalGuests: number;
    totalRsvps: number;
  };
}

export interface AdminInvitationDetailRes {
  message: string;
  status: number;
  data: AdminInvitationDetailData;
}

export function adminInvitationListResponse(invitations: AdminInvitationListItem[], pagination: AdminInvitationListPaginationMeta): AdminInvitationListRes {
  return {
    message: "Daftar seluruh undangan berhasil diambil",
    status: 200,
    data: {
      invitations,
      pagination,
    },
  };
}

export function adminInvitationDetailResponse(data: AdminInvitationDetailData): AdminInvitationDetailRes {
  return {
    message: "Detail undangan berhasil diambil",
    status: 200,
    data,
  };
}
